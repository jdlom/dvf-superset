--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.16
-- Dumped by pg_dump version 9.5.1

-- Started on 2019-05-20 13:09:08

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 124 (class 2615 OID 147916976)
-- Name: dvf; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dvf;


--
-- TOC entry 125 (class 2615 OID 147916977)
-- Name: dvf_annexe; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dvf_annexe;


SET search_path = dvf, pg_catalog;

--
-- TOC entry 3474 (class 1255 OID 147927756)
-- Name: adresse_dispoparc_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION adresse_dispoparc_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.adresse_dispoparc VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3470 (class 1255 OID 147927748)
-- Name: adresse_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION adresse_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.adresse VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.adresse VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3475 (class 1255 OID 147927758)
-- Name: adresse_local_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION adresse_local_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.adresse_local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.adresse_local VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3480 (class 1255 OID 151038316)
-- Name: centile(anyarray, integer); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION centile(anyarray, integer) RETURNS anyelement
    LANGUAGE sql
    AS $_$  
  SELECT t[$2/100.0 * array_upper($1,1) + 0.5] FROM (SELECT ARRAY(SELECT unnest($1) ORDER BY 1) as t) t1;
$_$;


--
-- TOC entry 3483 (class 1255 OID 151038319)
-- Name: dernier_quartile_0(anyarray); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION dernier_quartile_0(anyarray) RETURNS anyelement
    LANGUAGE sql
    AS $_$  
  SELECT dvf.centile($1, 75);
$_$;


--
-- TOC entry 3466 (class 1255 OID 147927740)
-- Name: disposition_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION disposition_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.disposition VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.disposition VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3467 (class 1255 OID 147927742)
-- Name: disposition_parcelle_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION disposition_parcelle_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.disposition_parcelle VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3477 (class 1255 OID 148010886)
-- Name: disposition_parcelle_plus_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION disposition_parcelle_plus_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.disposition_parcelle_plus VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3469 (class 1255 OID 147927746)
-- Name: local_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION local_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.local VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.local VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3476 (class 1255 OID 148010884)
-- Name: local_plus_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION local_plus_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.local_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.local_plus VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3473 (class 1255 OID 147927754)
-- Name: lot_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION lot_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.lot VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.lot VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3481 (class 1255 OID 151038317)
-- Name: mediane_0(anyarray); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION mediane_0(anyarray) RETURNS anyelement
    LANGUAGE sql
    AS $_$  
  SELECT dvf.centile($1, 50);
$_$;


--
-- TOC entry 3465 (class 1255 OID 147927738)
-- Name: mutation_article_cgi_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION mutation_article_cgi_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.mutation_article_cgi VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3464 (class 1255 OID 147927736)
-- Name: mutation_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION mutation_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.mutation VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.mutation VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3478 (class 1255 OID 148010888)
-- Name: mutation_plus_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION mutation_plus_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.mutation_plus VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3468 (class 1255 OID 147927744)
-- Name: parcelle_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION parcelle_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.parcelle VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.parcelle VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3482 (class 1255 OID 151038318)
-- Name: premier_quartile_0(anyarray); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION premier_quartile_0(anyarray) RETURNS anyelement
    LANGUAGE sql
    AS $_$  
  SELECT dvf.centile($1, 25);
$_$;


--
-- TOC entry 3471 (class 1255 OID 147927750)
-- Name: suf_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION suf_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.suf VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.suf VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 3472 (class 1255 OID 147927752)
-- Name: volume_insert_trigger(); Type: FUNCTION; Schema: dvf; Owner: -
--

CREATE FUNCTION volume_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
     IF (NEW.coddep='82') THEN INSERT INTO dvf_d82.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='50') THEN INSERT INTO dvf_d50.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='42') THEN INSERT INTO dvf_d42.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='48') THEN INSERT INTO dvf_d48.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='13') THEN INSERT INTO dvf_d13.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='41') THEN INSERT INTO dvf_d41.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='44') THEN INSERT INTO dvf_d44.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='10') THEN INSERT INTO dvf_d10.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='03') THEN INSERT INTO dvf_d03.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='27') THEN INSERT INTO dvf_d27.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='29') THEN INSERT INTO dvf_d29.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='89') THEN INSERT INTO dvf_d89.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='52') THEN INSERT INTO dvf_d52.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='61') THEN INSERT INTO dvf_d61.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='91') THEN INSERT INTO dvf_d91.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='45') THEN INSERT INTO dvf_d45.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='36') THEN INSERT INTO dvf_d36.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='79') THEN INSERT INTO dvf_d79.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='54') THEN INSERT INTO dvf_d54.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='85') THEN INSERT INTO dvf_d85.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='70') THEN INSERT INTO dvf_d70.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='12') THEN INSERT INTO dvf_d12.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='35') THEN INSERT INTO dvf_d35.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='39') THEN INSERT INTO dvf_d39.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='51') THEN INSERT INTO dvf_d51.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2B') THEN INSERT INTO dvf_d2b.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='83') THEN INSERT INTO dvf_d83.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='972') THEN INSERT INTO dvf_d972.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='30') THEN INSERT INTO dvf_d30.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='64') THEN INSERT INTO dvf_d64.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='28') THEN INSERT INTO dvf_d28.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='11') THEN INSERT INTO dvf_d11.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='78') THEN INSERT INTO dvf_d78.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='02') THEN INSERT INTO dvf_d02.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='90') THEN INSERT INTO dvf_d90.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='55') THEN INSERT INTO dvf_d55.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='66') THEN INSERT INTO dvf_d66.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='24') THEN INSERT INTO dvf_d24.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='09') THEN INSERT INTO dvf_d09.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='87') THEN INSERT INTO dvf_d87.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='84') THEN INSERT INTO dvf_d84.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='86') THEN INSERT INTO dvf_d86.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='21') THEN INSERT INTO dvf_d21.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='15') THEN INSERT INTO dvf_d15.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='18') THEN INSERT INTO dvf_d18.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='22') THEN INSERT INTO dvf_d22.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='46') THEN INSERT INTO dvf_d46.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='75') THEN INSERT INTO dvf_d75.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='31') THEN INSERT INTO dvf_d31.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='40') THEN INSERT INTO dvf_d40.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='80') THEN INSERT INTO dvf_d80.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='43') THEN INSERT INTO dvf_d43.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='59') THEN INSERT INTO dvf_d59.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='60') THEN INSERT INTO dvf_d60.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='973') THEN INSERT INTO dvf_d973.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='971') THEN INSERT INTO dvf_d971.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='65') THEN INSERT INTO dvf_d65.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='63') THEN INSERT INTO dvf_d63.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='07') THEN INSERT INTO dvf_d07.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='77') THEN INSERT INTO dvf_d77.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='2A') THEN INSERT INTO dvf_d2a.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='25') THEN INSERT INTO dvf_d25.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='94') THEN INSERT INTO dvf_d94.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='73') THEN INSERT INTO dvf_d73.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='71') THEN INSERT INTO dvf_d71.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='26') THEN INSERT INTO dvf_d26.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='17') THEN INSERT INTO dvf_d17.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='62') THEN INSERT INTO dvf_d62.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='93') THEN INSERT INTO dvf_d93.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='32') THEN INSERT INTO dvf_d32.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='37') THEN INSERT INTO dvf_d37.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='01') THEN INSERT INTO dvf_d01.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='92') THEN INSERT INTO dvf_d92.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='06') THEN INSERT INTO dvf_d06.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='49') THEN INSERT INTO dvf_d49.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='72') THEN INSERT INTO dvf_d72.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='974') THEN INSERT INTO dvf_d974.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='95') THEN INSERT INTO dvf_d95.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='05') THEN INSERT INTO dvf_d05.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='56') THEN INSERT INTO dvf_d56.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='88') THEN INSERT INTO dvf_d88.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='81') THEN INSERT INTO dvf_d81.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='33') THEN INSERT INTO dvf_d33.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='74') THEN INSERT INTO dvf_d74.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='76') THEN INSERT INTO dvf_d76.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='38') THEN INSERT INTO dvf_d38.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='04') THEN INSERT INTO dvf_d04.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='23') THEN INSERT INTO dvf_d23.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='14') THEN INSERT INTO dvf_d14.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='16') THEN INSERT INTO dvf_d16.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='19') THEN INSERT INTO dvf_d19.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='58') THEN INSERT INTO dvf_d58.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='69') THEN INSERT INTO dvf_d69.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='47') THEN INSERT INTO dvf_d47.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='08') THEN INSERT INTO dvf_d08.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='34') THEN INSERT INTO dvf_d34.volume VALUES(NEW.*); RETURN NULL;
ELSIF (NEW.coddep='53') THEN INSERT INTO dvf_d53.volume VALUES(NEW.*); RETURN NULL;
ELSE RETURN NULL;END IF;
    
END;
$$;


--
-- TOC entry 8998 (class 1255 OID 151038322)
-- Name: dernier_quartile(numeric); Type: AGGREGATE; Schema: dvf; Owner: -
--

CREATE AGGREGATE dernier_quartile(numeric) (
    SFUNC = array_append,
    STYPE = numeric[],
    FINALFUNC = dernier_quartile_0
);


--
-- TOC entry 8996 (class 1255 OID 151038320)
-- Name: mediane(numeric); Type: AGGREGATE; Schema: dvf; Owner: -
--

CREATE AGGREGATE mediane(numeric) (
    SFUNC = array_append,
    STYPE = numeric[],
    FINALFUNC = mediane_0
);


--
-- TOC entry 8997 (class 1255 OID 151038321)
-- Name: premier_quartile(numeric); Type: AGGREGATE; Schema: dvf; Owner: -
--

CREATE AGGREGATE premier_quartile(numeric) (
    SFUNC = array_append,
    STYPE = numeric[],
    FINALFUNC = premier_quartile_0
);


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 361 (class 1259 OID 147917022)
-- Name: adresse; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE adresse (
    idadresse integer NOT NULL,
    novoie integer,
    btq character varying(1),
    typvoie character varying(4),
    codvoie character varying(4),
    voie character varying(254),
    codepostal character varying(5),
    commune character varying(45),
    idadrinvar character varying(532),
    coddep character varying(3)
);


--
-- TOC entry 10941 (class 0 OID 0)
-- Dependencies: 361
-- Name: TABLE adresse; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE adresse IS 'table contenant les adresses (provenant des parcelles et des locaux';


--
-- TOC entry 10942 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.idadresse; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.idadresse IS 'identifiant pour clef primaire';


--
-- TOC entry 10943 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.novoie; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.novoie IS 'numéro de la voie';


--
-- TOC entry 10944 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.btq; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.btq IS 'indice de répétition';


--
-- TOC entry 10945 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.typvoie; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.typvoie IS 'type de voie';


--
-- TOC entry 10946 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.codvoie; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.codvoie IS 'code de la voie';


--
-- TOC entry 10947 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.voie; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.voie IS 'libellé de la voie';


--
-- TOC entry 10948 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.codepostal; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.codepostal IS 'code postal';


--
-- TOC entry 10949 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.commune; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.commune IS 'libellé de la commune';


--
-- TOC entry 10950 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.idadrinvar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.idadrinvar IS 'identifiant invariant de la table adresse';


--
-- TOC entry 10951 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN adresse.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse.coddep IS 'code du département';


--
-- TOC entry 368 (class 1259 OID 147917053)
-- Name: adresse_dispoparc; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE adresse_dispoparc (
    idadresse integer,
    iddispopar integer,
    coddep character varying(3),
    idmutation integer
);


--
-- TOC entry 10952 (class 0 OID 0)
-- Dependencies: 368
-- Name: TABLE adresse_dispoparc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE adresse_dispoparc IS 'table de liaison entre la table adresse et la table disposition_parcelle';


--
-- TOC entry 10953 (class 0 OID 0)
-- Dependencies: 368
-- Name: COLUMN adresse_dispoparc.idadresse; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_dispoparc.idadresse IS 'identifiant de la table adresse';


--
-- TOC entry 10954 (class 0 OID 0)
-- Dependencies: 368
-- Name: COLUMN adresse_dispoparc.iddispopar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_dispoparc.iddispopar IS 'identifiant de la table disposition_parcelle';


--
-- TOC entry 10955 (class 0 OID 0)
-- Dependencies: 368
-- Name: COLUMN adresse_dispoparc.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_dispoparc.coddep IS 'code du département';


--
-- TOC entry 10956 (class 0 OID 0)
-- Dependencies: 368
-- Name: COLUMN adresse_dispoparc.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_dispoparc.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 360 (class 1259 OID 147917020)
-- Name: adresse_idadresse_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE adresse_idadresse_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 10957 (class 0 OID 0)
-- Dependencies: 360
-- Name: adresse_idadresse_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE adresse_idadresse_seq OWNED BY adresse.idadresse;


--
-- TOC entry 369 (class 1259 OID 147917056)
-- Name: adresse_local; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE adresse_local (
    idadresse integer,
    iddispoloc integer,
    coddep character varying(3),
    idmutation integer
);


--
-- TOC entry 10958 (class 0 OID 0)
-- Dependencies: 369
-- Name: TABLE adresse_local; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE adresse_local IS 'table de liaison entre la table adresse et la table local';


--
-- TOC entry 10959 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN adresse_local.idadresse; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_local.idadresse IS 'identifiant de la table adresse';


--
-- TOC entry 10960 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN adresse_local.iddispoloc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_local.iddispoloc IS 'identifiant de la table local';


--
-- TOC entry 10961 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN adresse_local.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_local.coddep IS 'code du département';


--
-- TOC entry 10962 (class 0 OID 0)
-- Dependencies: 369
-- Name: COLUMN adresse_local.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN adresse_local.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 357 (class 1259 OID 147916992)
-- Name: disposition; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE disposition (
    iddispo integer NOT NULL,
    idmutation integer,
    nodispo integer,
    valeurfonc numeric,
    nblot integer,
    coddep character varying(3)
);


--
-- TOC entry 10963 (class 0 OID 0)
-- Dependencies: 357
-- Name: TABLE disposition; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE disposition IS 'table des dispositions';


--
-- TOC entry 10964 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN disposition.iddispo; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition.iddispo IS 'identifiant pour clef primaire';


--
-- TOC entry 10965 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN disposition.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 10966 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN disposition.nodispo; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition.nodispo IS 'numéro de disposition';


--
-- TOC entry 10967 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN disposition.valeurfonc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition.valeurfonc IS 'prix ou évaluation déclarée dans le cadre d''une mutation onéreuse';


--
-- TOC entry 10968 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN disposition.nblot; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition.nblot IS 'nombre total de lots dans la disposition';


--
-- TOC entry 10969 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN disposition.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition.coddep IS 'code du département';


--
-- TOC entry 356 (class 1259 OID 147916990)
-- Name: disposition_iddispo_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE disposition_iddispo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 10970 (class 0 OID 0)
-- Dependencies: 356
-- Name: disposition_iddispo_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE disposition_iddispo_seq OWNED BY disposition.iddispo;


--
-- TOC entry 1743 (class 1259 OID 148007376)
-- Name: disposition_parcelle; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE disposition_parcelle (
    iddispopar integer NOT NULL,
    iddispo integer,
    idparcelle integer,
    idmutation integer,
    idpar character varying(14),
    coddep character varying(3),
    codcomm character varying(3),
    prefsect character varying(3),
    nosect character varying(2),
    noplan character varying(4),
    datemut date,
    anneemut integer,
    moismut integer,
    parcvendue boolean,
    nbmutjour integer,
    nbmutannee integer,
    datemutpre date,
    l_idmutpre integer[],
    datemutsui date,
    l_idmutsui integer[],
    dcnt01 numeric,
    dcnt02 numeric,
    dcnt03 numeric,
    dcnt04 numeric,
    dcnt05 numeric,
    dcnt06 numeric,
    dcnt07 numeric,
    dcnt08 numeric,
    dcnt09 numeric,
    dcnt10 numeric,
    dcnt11 numeric,
    dcnt12 numeric,
    dcnt13 numeric,
    dcntsol numeric,
    dcntagri numeric,
    dcntnat numeric,
    geomloc public.geometry,
    geompar public.geometry
);


--
-- TOC entry 10971 (class 0 OID 0)
-- Dependencies: 1743
-- Name: TABLE disposition_parcelle; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE disposition_parcelle IS 'table des parcelles attachées à une disposition';


--
-- TOC entry 10972 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.iddispopar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.iddispopar IS 'identifiant pour clef primaire';


--
-- TOC entry 10973 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.iddispo; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.iddispo IS 'identifiant de la table disposition';


--
-- TOC entry 10974 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.idparcelle; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.idparcelle IS 'identifiant de la table parcelle';


--
-- TOC entry 10975 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 10976 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.idpar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.idpar IS 'identifiant de la parcelle (idem Fichiers fonciers)';


--
-- TOC entry 10977 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.coddep IS 'code du département';


--
-- TOC entry 10978 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.codcomm; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.codcomm IS 'code insee de la commune';


--
-- TOC entry 10979 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.prefsect; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.prefsect IS 'prefixe de section de la parcelle';


--
-- TOC entry 10980 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.nosect; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.nosect IS 'numéro de section de la parcelle';


--
-- TOC entry 10981 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.noplan; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.noplan IS 'numéro de la parcelle';


--
-- TOC entry 10982 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.datemut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.datemut IS 'date de signature du document (acte de vente)';


--
-- TOC entry 10983 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.anneemut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.anneemut IS 'annee de signature du document';


--
-- TOC entry 10984 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.moismut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.moismut IS 'mois de signature du document';


--
-- TOC entry 10985 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.parcvendue; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.parcvendue IS 'Vrai si la parcelle fait partie de la vente';


--
-- TOC entry 10986 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.nbmutjour; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.nbmutjour IS 'nombre de mutations de la parcelle au cours de la journée';


--
-- TOC entry 10987 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.nbmutannee; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.nbmutannee IS 'nombre de mutations de la parcelle au cours de l''année calendaire';


--
-- TOC entry 10988 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.datemutpre; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.datemutpre IS 'date de la précédente mutation de la parcelle (date antérieure)';


--
-- TOC entry 10989 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.l_idmutpre; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.l_idmutpre IS 'identifiants des mutations précédentes de la parcelle ayant eu lieu à la date de mutation précédente (datemutpre)';


--
-- TOC entry 10990 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.datemutsui; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.datemutsui IS 'date de la mutation suivante de la parcelle (date postérieure)';


--
-- TOC entry 10991 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.l_idmutsui; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.l_idmutsui IS 'identifiants des mutations suivantes de la parcelle ayant eu lieu à la date de mutation suivante (datemutsui)';


--
-- TOC entry 10992 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt01; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt01 IS 'surface de suf de type 01 ayant muté';


--
-- TOC entry 10993 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt02; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt02 IS 'surface de suf de type 02  ayant muté';


--
-- TOC entry 10994 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt03; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt03 IS 'surface de suf de type 03 ayant muté';


--
-- TOC entry 10995 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt04; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt04 IS 'surface de suf de type 04 ayant muté';


--
-- TOC entry 10996 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt05; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt05 IS 'surface de suf de type 05 ayant muté';


--
-- TOC entry 10997 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt06; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt06 IS 'surface de suf de type 06 ayant muté';


--
-- TOC entry 10998 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt07; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt07 IS 'surface de suf de type 07 ayant muté';


--
-- TOC entry 10999 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt08; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt08 IS 'surface de suf de type 08 ayant muté';


--
-- TOC entry 11000 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt09; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt09 IS 'surface de suf de type 09 ayant muté';


--
-- TOC entry 11001 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt10; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt10 IS 'surface de suf de type 10 ayant muté';


--
-- TOC entry 11002 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt11; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt11 IS 'surface de suf de type 11 ayant muté';


--
-- TOC entry 11003 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt12; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt12 IS 'surface de suf de type 12 ayant muté';


--
-- TOC entry 11004 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcnt13; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcnt13 IS 'surface de suf de type 13 ayant muté';


--
-- TOC entry 11005 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcntsol; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcntsol IS 'surface de suf de type sol ayant muté';


--
-- TOC entry 11006 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcntagri; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcntagri IS 'surface de suf de type agricole ayant muté';


--
-- TOC entry 11007 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.dcntnat; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.dcntnat IS 'surface de suf de type naturel ayant muté';


--
-- TOC entry 11008 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.geomloc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.geomloc IS 'géométrie du localisant de la parcelle';


--
-- TOC entry 11009 (class 0 OID 0)
-- Dependencies: 1743
-- Name: COLUMN disposition_parcelle.geompar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN disposition_parcelle.geompar IS 'géométrie du contour de la parcelle';


--
-- TOC entry 1742 (class 1259 OID 148007374)
-- Name: disposition_parcelle_plus_iddispopar_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE disposition_parcelle_plus_iddispopar_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11010 (class 0 OID 0)
-- Dependencies: 1742
-- Name: disposition_parcelle_plus_iddispopar_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE disposition_parcelle_plus_iddispopar_seq OWNED BY disposition_parcelle.iddispopar;


--
-- TOC entry 1741 (class 1259 OID 148007367)
-- Name: local; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE local (
    iddispoloc integer NOT NULL,
    iddispopar integer,
    idpar character varying(14),
    idmutation integer,
    idloc character varying(25),
    identloc character varying(7),
    codtyploc integer,
    libtyploc character varying(254),
    nbpprinc integer,
    sbati numeric,
    coddep character varying(3),
    datemut date,
    anneemut integer,
    moismut integer,
    nbmutjour integer,
    nbmutannee integer,
    datemutpre date,
    l_idmutpre integer[],
    datemutsui date,
    l_idmutsui integer[],
    geomloc public.geometry
);


--
-- TOC entry 11011 (class 0 OID 0)
-- Dependencies: 1741
-- Name: TABLE local; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE local IS 'table des locaux';


--
-- TOC entry 11012 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.iddispoloc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.iddispoloc IS 'identifiant de clef primaire de la table local';


--
-- TOC entry 11013 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.iddispopar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.iddispopar IS 'identifiant de la table disposition_parcelle';


--
-- TOC entry 11014 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.idpar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.idpar IS 'identifiant de la parcelle (idem Fichiers fonciers)';


--
-- TOC entry 11015 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 11016 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.idloc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.idloc IS 'identifiant du local (Fichier Fonciers)';


--
-- TOC entry 11017 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.identloc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.identloc IS 'identifiant du local';


--
-- TOC entry 11018 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.codtyploc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.codtyploc IS 'code du type de local';


--
-- TOC entry 11019 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.libtyploc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.libtyploc IS 'libellé du type de local';


--
-- TOC entry 11020 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.nbpprinc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.nbpprinc IS 'nombre de pièces principales';


--
-- TOC entry 11021 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.sbati; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.sbati IS 'surface réelle attachée à l''identifiant local';


--
-- TOC entry 11022 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.coddep IS 'code du département';


--
-- TOC entry 11023 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.datemut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.datemut IS 'date de signature du document (acte de vente)';


--
-- TOC entry 11024 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.anneemut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.anneemut IS 'annee de signature du document';


--
-- TOC entry 11025 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.moismut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.moismut IS 'mois de signature du document';


--
-- TOC entry 11026 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.nbmutjour; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.nbmutjour IS 'nombre de mutations du local au cours de la journée';


--
-- TOC entry 11027 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.nbmutannee; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.nbmutannee IS 'nombre de mutations du local au cours de l''année calendaire';


--
-- TOC entry 11028 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.datemutpre; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.datemutpre IS 'date de la précédente mutation du local';


--
-- TOC entry 11029 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.l_idmutpre; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.l_idmutpre IS 'identifiants des mutations précédentes du local ayant eu lieu à la date de mutation précédente (datemutpre)';


--
-- TOC entry 11030 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.datemutsui; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.datemutsui IS 'date de la mutation suivante du local';


--
-- TOC entry 11031 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.l_idmutsui; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.l_idmutsui IS 'identifiants des mutations suivantes du local ayant eu lieu à la date de mutation suivante (datemutsui)';


--
-- TOC entry 11032 (class 0 OID 0)
-- Dependencies: 1741
-- Name: COLUMN local.geomloc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN local.geomloc IS 'géométrie du localisant';


--
-- TOC entry 1740 (class 1259 OID 148007365)
-- Name: local_plus_iddispoloc_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE local_plus_iddispoloc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11033 (class 0 OID 0)
-- Dependencies: 1740
-- Name: local_plus_iddispoloc_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE local_plus_iddispoloc_seq OWNED BY local.iddispoloc;


--
-- TOC entry 367 (class 1259 OID 147917046)
-- Name: lot; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE lot (
    iddispolot integer NOT NULL,
    iddispopar integer,
    idmutation integer,
    iddispoloc integer,
    nolot character varying(7),
    scarrez numeric,
    coddep character varying(3)
);


--
-- TOC entry 11034 (class 0 OID 0)
-- Dependencies: 367
-- Name: TABLE lot; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE lot IS 'table des lots (seuls les 5 premiers lots sont mentionnés)';


--
-- TOC entry 11035 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN lot.iddispolot; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN lot.iddispolot IS 'identifiant pour clef primaire';


--
-- TOC entry 11036 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN lot.iddispopar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN lot.iddispopar IS 'identifiant de la table disposition_parcelle';


--
-- TOC entry 11037 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN lot.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN lot.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 11038 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN lot.iddispoloc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN lot.iddispoloc IS 'identifiant de la table local';


--
-- TOC entry 11039 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN lot.nolot; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN lot.nolot IS 'numéro du lot';


--
-- TOC entry 11040 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN lot.scarrez; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN lot.scarrez IS 'surface Loi Carrez du lot';


--
-- TOC entry 11041 (class 0 OID 0)
-- Dependencies: 367
-- Name: COLUMN lot.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN lot.coddep IS 'code du département';


--
-- TOC entry 366 (class 1259 OID 147917044)
-- Name: lot_iddispolot_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE lot_iddispolot_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11042 (class 0 OID 0)
-- Dependencies: 366
-- Name: lot_iddispolot_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE lot_iddispolot_seq OWNED BY lot.iddispolot;


--
-- TOC entry 1745 (class 1259 OID 148007385)
-- Name: mutation; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE mutation (
    idmutation integer NOT NULL,
    idmutinvar character varying(60),
    idopendata character varying(60),
    idnatmut integer,
    codservch character varying(7),
    refdoc character varying(10),
    datemut date,
    anneemut integer,
    moismut integer,
    coddep character varying(3),
    libnatmut character varying(45),
    nbartcgi integer,
    l_artcgi character varying[],
    vefa boolean,
    valeurfonc numeric,
    nbdispo integer,
    nblot integer,
    nbcomm integer,
    l_codinsee character varying[],
    nbsection integer,
    l_section character varying[],
    nbpar integer,
    l_idpar character varying[],
    nbparmut integer,
    l_idparmut character varying[],
    nbsuf integer,
    sterr numeric,
    l_dcnt numeric[],
    nbvolmut integer,
    nblocmut integer,
    l_idlocmut character varying[],
    nblocmai integer,
    nblocapt integer,
    nblocdep integer,
    nblocact integer,
    nbapt1pp integer,
    nbapt2pp integer,
    nbapt3pp integer,
    nbapt4pp integer,
    nbapt5pp integer,
    nbmai1pp integer,
    nbmai2pp integer,
    nbmai3pp integer,
    nbmai4pp integer,
    nbmai5pp integer,
    sbati numeric,
    sbatmai numeric,
    sbatapt numeric,
    sbatact numeric,
    sapt1pp numeric,
    sapt2pp numeric,
    sapt3pp numeric,
    sapt4pp numeric,
    sapt5pp numeric,
    smai1pp numeric,
    smai2pp numeric,
    smai3pp numeric,
    smai4pp numeric,
    smai5pp numeric,
    geomlocmut public.geometry,
    geomparmut public.geometry,
    geompar public.geometry,
    codtypbien character varying(6),
    libtypbien text
);


--
-- TOC entry 11043 (class 0 OID 0)
-- Dependencies: 1745
-- Name: TABLE mutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE mutation IS 'table des mutations';


--
-- TOC entry 11044 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 11045 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.idmutinvar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.idmutinvar IS 'identifiant invariant de la mutation';


--
-- TOC entry 11046 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.idopendata; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.idopendata IS 'identifiant de mutation';


--
-- TOC entry 11047 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.idnatmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.idnatmut IS 'identifiant de clef primaire de la table ann_nature_mutation';


--
-- TOC entry 11048 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.codservch; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.codservch IS 'code du service de conservation des hypothèques';


--
-- TOC entry 11049 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.refdoc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.refdoc IS 'référence d''enregistrement du document (acte de vente)';


--
-- TOC entry 11050 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.datemut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.datemut IS 'date de signature du document (acte de vente)';


--
-- TOC entry 11051 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.anneemut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.anneemut IS 'annee de signature du document';


--
-- TOC entry 11052 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.moismut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.moismut IS 'mois de signature du document';


--
-- TOC entry 11053 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.coddep IS 'code du département';


--
-- TOC entry 11054 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.libnatmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.libnatmut IS 'libellé de la nature de mutation';


--
-- TOC entry 11055 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbartcgi; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbartcgi IS 'nombre d''articles du Code Général des Impôts (CGI) associés à la mutation';


--
-- TOC entry 11056 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.l_artcgi; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.l_artcgi IS 'liste des codes d''articles CGI (Code Général des Impôts) associés à la mutation';


--
-- TOC entry 11057 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.vefa; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.vefa IS 'vrai si la mutation est une Vente en l''état futur d''achèvement (VEFA)';


--
-- TOC entry 11058 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.valeurfonc; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.valeurfonc IS 'prix ou évaluation déclarée dans le cadre d''une mutation onéreuse';


--
-- TOC entry 11059 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbdispo; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbdispo IS 'nombre de dispositions associées à la mutation';


--
-- TOC entry 11060 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nblot; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nblot IS 'nombre total de lots dans la mutation';


--
-- TOC entry 11061 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbcomm; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbcomm IS 'nombre de communes concernées par la mutation';


--
-- TOC entry 11062 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.l_codinsee; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.l_codinsee IS 'liste des codes INSEE des communes concernées par la mutation';


--
-- TOC entry 11063 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbsection; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbsection IS 'nombre de sections concernées par la mutation';


--
-- TOC entry 11064 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.l_section; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.l_section IS 'liste des sections concernées par la mutation';


--
-- TOC entry 11065 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbpar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbpar IS 'nombre de parcelles concernées par la mutation';


--
-- TOC entry 11066 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.l_idpar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.l_idpar IS 'liste des identifiants de parcelles concernées par la mutation (idpar)';


--
-- TOC entry 11067 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbparmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbparmut IS 'nombre de parcelles ayant muté';


--
-- TOC entry 11068 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.l_idparmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.l_idparmut IS 'liste des identifiants de parcelles ayant muté (idpar)';


--
-- TOC entry 11069 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbsuf; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbsuf IS 'nombre de subdivisions fiscales ayant muté';


--
-- TOC entry 11070 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sterr; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sterr IS 'surface de terrain ayant muté';


--
-- TOC entry 11071 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.l_dcnt; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.l_dcnt IS 'Liste ordonnée des surfaces de suf de 01 à 13';


--
-- TOC entry 11072 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbvolmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbvolmut IS 'nombre de volumes ayant muté';


--
-- TOC entry 11073 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nblocmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nblocmut IS 'nombre de locaux ayant muté';


--
-- TOC entry 11074 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.l_idlocmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.l_idlocmut IS 'liste des identifiants de locaux ayant muté (idloc)';


--
-- TOC entry 11075 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nblocmai; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nblocmai IS 'nombre de maisons ayant muté';


--
-- TOC entry 11076 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nblocapt; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nblocapt IS 'nombre d''appartements ayant muté';


--
-- TOC entry 11077 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nblocdep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nblocdep IS 'nombre de dépendances ayant muté';


--
-- TOC entry 11078 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nblocact; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nblocact IS 'nombre de locaux d''activités ayant muté';


--
-- TOC entry 11079 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbapt1pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbapt1pp IS 'nombre d''appartements avec au plus une pièce principale ayant muté';


--
-- TOC entry 11080 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbapt2pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbapt2pp IS 'nombre d''appartements avec 2 pièces principales ayant muté';


--
-- TOC entry 11081 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbapt3pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbapt3pp IS 'nombre d''appartements avec 3 pièces principales ayant muté';


--
-- TOC entry 11082 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbapt4pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbapt4pp IS 'nombre d''appartements avec 4 pièces principales ayant muté';


--
-- TOC entry 11083 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbapt5pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbapt5pp IS 'nombre d''appartements avec au moins 5 pièces principales ayant muté';


--
-- TOC entry 11084 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbmai1pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbmai1pp IS 'nombre de maisons avec au plus une pièce principale ayant muté';


--
-- TOC entry 11085 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbmai2pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbmai2pp IS 'nombre de maisons avec 2 pièces principales ayant muté';


--
-- TOC entry 11086 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbmai3pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbmai3pp IS 'nombre de maisons avec 3 pièces principales ayant muté';


--
-- TOC entry 11087 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbmai4pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbmai4pp IS 'nombre de maisons avec 4 pièces principales ayant muté';


--
-- TOC entry 11088 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.nbmai5pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.nbmai5pp IS 'nombre de maisons avec au moins 5 pièces principales ayant muté';


--
-- TOC entry 11089 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sbati; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sbati IS 'surface de l''ensemble du bâti ayant muté';


--
-- TOC entry 11090 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sbatmai; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sbatmai IS 'surface de l''ensemble des maisons ayant muté';


--
-- TOC entry 11091 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sbatapt; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sbatapt IS 'surface de l''ensemble des appartements ayant muté';


--
-- TOC entry 11092 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sbatact; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sbatact IS 'surface de l''ensemble du bâti d''activité ayant muté';


--
-- TOC entry 11093 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sapt1pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sapt1pp IS 'surface de l''ensemble des appartements avec au plus une pièce principale ayant muté';


--
-- TOC entry 11094 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sapt2pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sapt2pp IS 'surface de l''ensemble des appartements avec 2 pièces principales ayant muté';


--
-- TOC entry 11095 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sapt3pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sapt3pp IS 'surface de l''ensemble des appartements avec 3 pièces principales ayant muté';


--
-- TOC entry 11096 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sapt4pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sapt4pp IS 'surface de l''ensemble des appartements avec 4 pièces principales ayant muté';


--
-- TOC entry 11097 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.sapt5pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.sapt5pp IS 'surface de l''ensemble des appartements avec au moins 5 pièces principales ayant muté';


--
-- TOC entry 11098 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.smai1pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.smai1pp IS 'surface de l''ensemble des maisons avec au plus une pièce principale ayant muté';


--
-- TOC entry 11099 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.smai2pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.smai2pp IS 'surface de l''ensemble des maisons avec 2 pièces principales ayant muté';


--
-- TOC entry 11100 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.smai3pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.smai3pp IS 'surface de l''ensemble des maisons avec 3 pièces principales ayant muté';


--
-- TOC entry 11101 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.smai4pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.smai4pp IS 'surface de l''ensemble des maisons avec 4 pièces principales ayant muté';


--
-- TOC entry 11102 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.smai5pp; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.smai5pp IS 'surface de l''ensemble des maisons avec au moins 5 pièces principales ayant muté';


--
-- TOC entry 11103 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.geomlocmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.geomlocmut IS 'géométrie de l''ensemble des localisants correspondant à des parcelles surlesquelles un local a muté';


--
-- TOC entry 11104 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.geomparmut; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.geomparmut IS 'géométrie de l''ensemble des contours des parcelles ayant muté';


--
-- TOC entry 11105 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.geompar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.geompar IS 'geométrie de l''ensemble des contours des parcelles concernées par la mutation';


--
-- TOC entry 11106 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.codtypbien; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.codtypbien IS 'code de la typologie des biens du GnDVF';


--
-- TOC entry 11107 (class 0 OID 0)
-- Dependencies: 1745
-- Name: COLUMN mutation.libtypbien; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation.libtypbien IS 'libellé de la typologie des biens du GnDVF';


--
-- TOC entry 355 (class 1259 OID 147916987)
-- Name: mutation_article_cgi; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE mutation_article_cgi (
    idmutation integer,
    idartcgi integer,
    ordarticgi integer,
    coddep character varying(3)
);


--
-- TOC entry 11108 (class 0 OID 0)
-- Dependencies: 355
-- Name: TABLE mutation_article_cgi; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE mutation_article_cgi IS 'table des articles du code général des impôts (CGI) attachés à la mutation';


--
-- TOC entry 11109 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN mutation_article_cgi.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation_article_cgi.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 11110 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN mutation_article_cgi.idartcgi; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation_article_cgi.idartcgi IS 'identifiant de la table annexe ann_cgi';


--
-- TOC entry 11111 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN mutation_article_cgi.ordarticgi; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation_article_cgi.ordarticgi IS 'numéro de l''ordre de l''article cgi';


--
-- TOC entry 11112 (class 0 OID 0)
-- Dependencies: 355
-- Name: COLUMN mutation_article_cgi.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN mutation_article_cgi.coddep IS 'code du département';


--
-- TOC entry 1744 (class 1259 OID 148007383)
-- Name: mutation_plus_idmutation_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE mutation_plus_idmutation_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11113 (class 0 OID 0)
-- Dependencies: 1744
-- Name: mutation_plus_idmutation_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE mutation_plus_idmutation_seq OWNED BY mutation.idmutation;


--
-- TOC entry 359 (class 1259 OID 147917007)
-- Name: parcelle; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE parcelle (
    idparcelle integer NOT NULL,
    idpar character varying(14),
    coddep character varying(3),
    codcomm character varying(3),
    prefsect character varying(3),
    nosect character varying(2),
    noplan character varying(4)
);


--
-- TOC entry 11114 (class 0 OID 0)
-- Dependencies: 359
-- Name: TABLE parcelle; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE parcelle IS 'table des parcelles';


--
-- TOC entry 11115 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN parcelle.idparcelle; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN parcelle.idparcelle IS 'identifiant pour clef primaire';


--
-- TOC entry 11116 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN parcelle.idpar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN parcelle.idpar IS 'identifiant de la parcelle (idem Fichiers fonciers)';


--
-- TOC entry 11117 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN parcelle.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN parcelle.coddep IS 'code du département';


--
-- TOC entry 11118 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN parcelle.codcomm; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN parcelle.codcomm IS 'code insee de la commune';


--
-- TOC entry 11119 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN parcelle.prefsect; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN parcelle.prefsect IS 'prefixe de section de la parcelle';


--
-- TOC entry 11120 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN parcelle.nosect; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN parcelle.nosect IS 'numéro de section de la parcelle';


--
-- TOC entry 11121 (class 0 OID 0)
-- Dependencies: 359
-- Name: COLUMN parcelle.noplan; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN parcelle.noplan IS 'numéro de la parcelle';


--
-- TOC entry 358 (class 1259 OID 147917005)
-- Name: parcelle_idparcelle_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE parcelle_idparcelle_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11122 (class 0 OID 0)
-- Dependencies: 358
-- Name: parcelle_idparcelle_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE parcelle_idparcelle_seq OWNED BY parcelle.idparcelle;


--
-- TOC entry 363 (class 1259 OID 147917031)
-- Name: suf; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE suf (
    iddisposuf integer NOT NULL,
    iddispopar integer,
    idmutation integer,
    nbsufidt integer,
    sterr numeric,
    natcult character varying(2),
    natcultspe character varying(5),
    idsufinvar character varying(18),
    coddep character varying(3),
    nodcnt integer
);


--
-- TOC entry 11123 (class 0 OID 0)
-- Dependencies: 363
-- Name: TABLE suf; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE suf IS 'table des subdivisions fiscales';


--
-- TOC entry 11124 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.iddisposuf; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.iddisposuf IS 'identifiant pour clef primaire';


--
-- TOC entry 11125 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.iddispopar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.iddispopar IS 'identifiant de la table disposition_parcelle';


--
-- TOC entry 11126 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 11127 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.nbsufidt; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.nbsufidt IS 'nombre de suf identiques';


--
-- TOC entry 11128 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.sterr; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.sterr IS 'surface de terrain ayant muté';


--
-- TOC entry 11129 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.natcult; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.natcult IS 'libellé de nature de culture';


--
-- TOC entry 11130 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.natcultspe; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.natcultspe IS 'groupe de nature de culture spéciale';


--
-- TOC entry 11131 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.idsufinvar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.idsufinvar IS 'identifiant invariant de la table suf';


--
-- TOC entry 11132 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.coddep IS 'code du département';


--
-- TOC entry 11133 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN suf.nodcnt; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN suf.nodcnt IS 'type de la suf';


--
-- TOC entry 362 (class 1259 OID 147917029)
-- Name: suf_iddisposuf_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE suf_iddisposuf_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11134 (class 0 OID 0)
-- Dependencies: 362
-- Name: suf_iddisposuf_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE suf_iddisposuf_seq OWNED BY suf.iddisposuf;


--
-- TOC entry 365 (class 1259 OID 147917040)
-- Name: volume; Type: TABLE; Schema: dvf; Owner: -
--

CREATE TABLE volume (
    iddispovol integer NOT NULL,
    iddispopar integer,
    idmutation integer,
    novolume character varying(7),
    coddep character varying(3)
);


--
-- TOC entry 11135 (class 0 OID 0)
-- Dependencies: 365
-- Name: TABLE volume; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON TABLE volume IS 'table des volumes (division de l''espace dans la hauteur pour certaines co-propriétés verticales';


--
-- TOC entry 11136 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN volume.iddispovol; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN volume.iddispovol IS 'identifiant pour clef primaire';


--
-- TOC entry 11137 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN volume.iddispopar; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN volume.iddispopar IS 'identifiant de la table disposition_parcelle';


--
-- TOC entry 11138 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN volume.idmutation; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN volume.idmutation IS 'identifiant de clef primaire de la table mutation';


--
-- TOC entry 11139 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN volume.novolume; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN volume.novolume IS 'numéro de volume';


--
-- TOC entry 11140 (class 0 OID 0)
-- Dependencies: 365
-- Name: COLUMN volume.coddep; Type: COMMENT; Schema: dvf; Owner: -
--

COMMENT ON COLUMN volume.coddep IS 'code du département';


--
-- TOC entry 364 (class 1259 OID 147917038)
-- Name: volume_iddispovol_seq; Type: SEQUENCE; Schema: dvf; Owner: -
--

CREATE SEQUENCE volume_iddispovol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11141 (class 0 OID 0)
-- Dependencies: 364
-- Name: volume_iddispovol_seq; Type: SEQUENCE OWNED BY; Schema: dvf; Owner: -
--

ALTER SEQUENCE volume_iddispovol_seq OWNED BY volume.iddispovol;


SET search_path = dvf_annexe, pg_catalog;

--
-- TOC entry 1246 (class 1259 OID 147927768)
-- Name: ann_cgi; Type: TABLE; Schema: dvf_annexe; Owner: -
--

CREATE TABLE ann_cgi (
    idartcgi integer NOT NULL,
    artcgi character varying(20),
    libartcgi character varying(254)
);


--
-- TOC entry 11142 (class 0 OID 0)
-- Dependencies: 1246
-- Name: TABLE ann_cgi; Type: COMMENT; Schema: dvf_annexe; Owner: -
--

COMMENT ON TABLE ann_cgi IS 'table contenant les différents articles CGI';


--
-- TOC entry 1245 (class 1259 OID 147927766)
-- Name: ann_cgi_idartcgi_seq; Type: SEQUENCE; Schema: dvf_annexe; Owner: -
--

CREATE SEQUENCE ann_cgi_idartcgi_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11143 (class 0 OID 0)
-- Dependencies: 1245
-- Name: ann_cgi_idartcgi_seq; Type: SEQUENCE OWNED BY; Schema: dvf_annexe; Owner: -
--

ALTER SEQUENCE ann_cgi_idartcgi_seq OWNED BY ann_cgi.idartcgi;


--
-- TOC entry 1243 (class 1259 OID 147927760)
-- Name: ann_nature_culture; Type: TABLE; Schema: dvf_annexe; Owner: -
--

CREATE TABLE ann_nature_culture (
    natcult character varying(2),
    libnatcult character varying(254)
);


--
-- TOC entry 11144 (class 0 OID 0)
-- Dependencies: 1243
-- Name: TABLE ann_nature_culture; Type: COMMENT; Schema: dvf_annexe; Owner: -
--

COMMENT ON TABLE ann_nature_culture IS 'table contenant les différentes natures de culture';


--
-- TOC entry 1244 (class 1259 OID 147927763)
-- Name: ann_nature_culture_speciale; Type: TABLE; Schema: dvf_annexe; Owner: -
--

CREATE TABLE ann_nature_culture_speciale (
    natcultspe character varying(5),
    libnatcusp character varying(254)
);


--
-- TOC entry 11145 (class 0 OID 0)
-- Dependencies: 1244
-- Name: TABLE ann_nature_culture_speciale; Type: COMMENT; Schema: dvf_annexe; Owner: -
--

COMMENT ON TABLE ann_nature_culture_speciale IS 'table contenant les différentes natures de culture spéciale';


--
-- TOC entry 1248 (class 1259 OID 147927774)
-- Name: ann_nature_mutation; Type: TABLE; Schema: dvf_annexe; Owner: -
--

CREATE TABLE ann_nature_mutation (
    idnatmut integer NOT NULL,
    libnatmut character varying(45)
);


--
-- TOC entry 11146 (class 0 OID 0)
-- Dependencies: 1248
-- Name: TABLE ann_nature_mutation; Type: COMMENT; Schema: dvf_annexe; Owner: -
--

COMMENT ON TABLE ann_nature_mutation IS 'table contenant les natures de mutation';


--
-- TOC entry 11147 (class 0 OID 0)
-- Dependencies: 1248
-- Name: COLUMN ann_nature_mutation.idnatmut; Type: COMMENT; Schema: dvf_annexe; Owner: -
--

COMMENT ON COLUMN ann_nature_mutation.idnatmut IS 'identifiant de clef primaire de la table ann_nature_mutation';


--
-- TOC entry 11148 (class 0 OID 0)
-- Dependencies: 1248
-- Name: COLUMN ann_nature_mutation.libnatmut; Type: COMMENT; Schema: dvf_annexe; Owner: -
--

COMMENT ON COLUMN ann_nature_mutation.libnatmut IS 'libellé de la nature de mutation';


--
-- TOC entry 1247 (class 1259 OID 147927772)
-- Name: ann_nature_mutation_idnatmut_seq; Type: SEQUENCE; Schema: dvf_annexe; Owner: -
--

CREATE SEQUENCE ann_nature_mutation_idnatmut_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 11149 (class 0 OID 0)
-- Dependencies: 1247
-- Name: ann_nature_mutation_idnatmut_seq; Type: SEQUENCE OWNED BY; Schema: dvf_annexe; Owner: -
--

ALTER SEQUENCE ann_nature_mutation_idnatmut_seq OWNED BY ann_nature_mutation.idnatmut;


--
-- TOC entry 1249 (class 1259 OID 147927778)
-- Name: ann_type_local; Type: TABLE; Schema: dvf_annexe; Owner: -
--

CREATE TABLE ann_type_local (
    codtyploc integer,
    libtyploc character varying(254)
);


--
-- TOC entry 11150 (class 0 OID 0)
-- Dependencies: 1249
-- Name: TABLE ann_type_local; Type: COMMENT; Schema: dvf_annexe; Owner: -
--

COMMENT ON TABLE ann_type_local IS 'table contenant les types de locaux';


--
-- TOC entry 2038 (class 1259 OID 150797923)
-- Name: ann_typologie; Type: TABLE; Schema: dvf_annexe; Owner: -
--

CREATE TABLE ann_typologie (
    codtypbien character varying(5),
    libtypbien text,
    niv1 character varying(1),
    libniv1 character varying,
    niv2 character varying(2),
    libniv2 character varying,
    niv3 character varying(3),
    libniv3 character varying,
    niv4 character varying(4),
    libniv4 character varying,
    niv5 character varying(5),
    libniv5 character varying
);


SET search_path = dvf, pg_catalog;

--
-- TOC entry 10564 (class 2604 OID 147917025)
-- Name: idadresse; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY adresse ALTER COLUMN idadresse SET DEFAULT nextval('adresse_idadresse_seq'::regclass);


--
-- TOC entry 10562 (class 2604 OID 147916995)
-- Name: iddispo; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY disposition ALTER COLUMN iddispo SET DEFAULT nextval('disposition_iddispo_seq'::regclass);


--
-- TOC entry 10571 (class 2604 OID 148007379)
-- Name: iddispopar; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY disposition_parcelle ALTER COLUMN iddispopar SET DEFAULT nextval('disposition_parcelle_plus_iddispopar_seq'::regclass);


--
-- TOC entry 10570 (class 2604 OID 148007370)
-- Name: iddispoloc; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY local ALTER COLUMN iddispoloc SET DEFAULT nextval('local_plus_iddispoloc_seq'::regclass);


--
-- TOC entry 10567 (class 2604 OID 147917049)
-- Name: iddispolot; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY lot ALTER COLUMN iddispolot SET DEFAULT nextval('lot_iddispolot_seq'::regclass);


--
-- TOC entry 10572 (class 2604 OID 148007388)
-- Name: idmutation; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY mutation ALTER COLUMN idmutation SET DEFAULT nextval('mutation_plus_idmutation_seq'::regclass);


--
-- TOC entry 10563 (class 2604 OID 147917010)
-- Name: idparcelle; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY parcelle ALTER COLUMN idparcelle SET DEFAULT nextval('parcelle_idparcelle_seq'::regclass);


--
-- TOC entry 10565 (class 2604 OID 147917034)
-- Name: iddisposuf; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY suf ALTER COLUMN iddisposuf SET DEFAULT nextval('suf_iddisposuf_seq'::regclass);


--
-- TOC entry 10566 (class 2604 OID 147917043)
-- Name: iddispovol; Type: DEFAULT; Schema: dvf; Owner: -
--

ALTER TABLE ONLY volume ALTER COLUMN iddispovol SET DEFAULT nextval('volume_iddispovol_seq'::regclass);


SET search_path = dvf_annexe, pg_catalog;

--
-- TOC entry 10568 (class 2604 OID 147927771)
-- Name: idartcgi; Type: DEFAULT; Schema: dvf_annexe; Owner: -
--

ALTER TABLE ONLY ann_cgi ALTER COLUMN idartcgi SET DEFAULT nextval('ann_cgi_idartcgi_seq'::regclass);


--
-- TOC entry 10569 (class 2604 OID 147927777)
-- Name: idnatmut; Type: DEFAULT; Schema: dvf_annexe; Owner: -
--

ALTER TABLE ONLY ann_nature_mutation ALTER COLUMN idnatmut SET DEFAULT nextval('ann_nature_mutation_idnatmut_seq'::regclass);


SET search_path = dvf, pg_catalog;

--
-- TOC entry 10914 (class 0 OID 147917022)
-- Dependencies: 361
-- Data for Name: adresse; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY adresse (idadresse, novoie, btq, typvoie, codvoie, voie, codepostal, commune, idadrinvar, coddep) FROM stdin;
\.


--
-- TOC entry 10921 (class 0 OID 147917053)
-- Dependencies: 368
-- Data for Name: adresse_dispoparc; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY adresse_dispoparc (idadresse, iddispopar, coddep, idmutation) FROM stdin;
\.


--
-- TOC entry 11151 (class 0 OID 0)
-- Dependencies: 360
-- Name: adresse_idadresse_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('adresse_idadresse_seq', 4352108, true);


--
-- TOC entry 10922 (class 0 OID 147917056)
-- Dependencies: 369
-- Data for Name: adresse_local; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY adresse_local (idadresse, iddispoloc, coddep, idmutation) FROM stdin;
\.


--
-- TOC entry 10910 (class 0 OID 147916992)
-- Dependencies: 357
-- Data for Name: disposition; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY disposition (iddispo, idmutation, nodispo, valeurfonc, nblot, coddep) FROM stdin;
\.


--
-- TOC entry 11152 (class 0 OID 0)
-- Dependencies: 356
-- Name: disposition_iddispo_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('disposition_iddispo_seq', 6060066, true);


--
-- TOC entry 10933 (class 0 OID 148007376)
-- Dependencies: 1743
-- Data for Name: disposition_parcelle; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY disposition_parcelle (iddispopar, iddispo, idparcelle, idmutation, idpar, coddep, codcomm, prefsect, nosect, noplan, datemut, anneemut, moismut, parcvendue, nbmutjour, nbmutannee, datemutpre, l_idmutpre, datemutsui, l_idmutsui, dcnt01, dcnt02, dcnt03, dcnt04, dcnt05, dcnt06, dcnt07, dcnt08, dcnt09, dcnt10, dcnt11, dcnt12, dcnt13, dcntsol, dcntagri, dcntnat, geomloc, geompar) FROM stdin;
\.


--
-- TOC entry 11153 (class 0 OID 0)
-- Dependencies: 1742
-- Name: disposition_parcelle_plus_iddispopar_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('disposition_parcelle_plus_iddispopar_seq', 10268610, true);


--
-- TOC entry 10931 (class 0 OID 148007367)
-- Dependencies: 1741
-- Data for Name: local; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY local (iddispoloc, iddispopar, idpar, idmutation, idloc, identloc, codtyploc, libtyploc, nbpprinc, sbati, coddep, datemut, anneemut, moismut, nbmutjour, nbmutannee, datemutpre, l_idmutpre, datemutsui, l_idmutsui, geomloc) FROM stdin;
\.


--
-- TOC entry 11154 (class 0 OID 0)
-- Dependencies: 1740
-- Name: local_plus_iddispoloc_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('local_plus_iddispoloc_seq', 6941219, true);


--
-- TOC entry 10920 (class 0 OID 147917046)
-- Dependencies: 367
-- Data for Name: lot; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY lot (iddispolot, iddispopar, idmutation, iddispoloc, nolot, scarrez, coddep) FROM stdin;
\.


--
-- TOC entry 11155 (class 0 OID 0)
-- Dependencies: 366
-- Name: lot_iddispolot_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('lot_iddispolot_seq', 5321202, true);


--
-- TOC entry 10935 (class 0 OID 148007385)
-- Dependencies: 1745
-- Data for Name: mutation; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY mutation (idmutation, idmutinvar, idopendata, idnatmut, codservch, refdoc, datemut, anneemut, moismut, coddep, libnatmut, nbartcgi, l_artcgi, vefa, valeurfonc, nbdispo, nblot, nbcomm, l_codinsee, nbsection, l_section, nbpar, l_idpar, nbparmut, l_idparmut, nbsuf, sterr, l_dcnt, nbvolmut, nblocmut, l_idlocmut, nblocmai, nblocapt, nblocdep, nblocact, nbapt1pp, nbapt2pp, nbapt3pp, nbapt4pp, nbapt5pp, nbmai1pp, nbmai2pp, nbmai3pp, nbmai4pp, nbmai5pp, sbati, sbatmai, sbatapt, sbatact, sapt1pp, sapt2pp, sapt3pp, sapt4pp, sapt5pp, smai1pp, smai2pp, smai3pp, smai4pp, smai5pp, geomlocmut, geomparmut, geompar, codtypbien, libtypbien) FROM stdin;
\.


--
-- TOC entry 10908 (class 0 OID 147916987)
-- Dependencies: 355
-- Data for Name: mutation_article_cgi; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY mutation_article_cgi (idmutation, idartcgi, ordarticgi, coddep) FROM stdin;
\.


--
-- TOC entry 11156 (class 0 OID 0)
-- Dependencies: 1744
-- Name: mutation_plus_idmutation_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('mutation_plus_idmutation_seq', 5915376, true);


--
-- TOC entry 10912 (class 0 OID 147917007)
-- Dependencies: 359
-- Data for Name: parcelle; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY parcelle (idparcelle, idpar, coddep, codcomm, prefsect, nosect, noplan) FROM stdin;
\.


--
-- TOC entry 11157 (class 0 OID 0)
-- Dependencies: 358
-- Name: parcelle_idparcelle_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('parcelle_idparcelle_seq', 7783738, true);


--
-- TOC entry 10916 (class 0 OID 147917031)
-- Dependencies: 363
-- Data for Name: suf; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY suf (iddisposuf, iddispopar, idmutation, nbsufidt, sterr, natcult, natcultspe, idsufinvar, coddep, nodcnt) FROM stdin;
\.


--
-- TOC entry 11158 (class 0 OID 0)
-- Dependencies: 362
-- Name: suf_iddisposuf_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('suf_iddisposuf_seq', 8667383, true);


--
-- TOC entry 10918 (class 0 OID 147917040)
-- Dependencies: 365
-- Data for Name: volume; Type: TABLE DATA; Schema: dvf; Owner: -
--

COPY volume (iddispovol, iddispopar, idmutation, novolume, coddep) FROM stdin;
\.


--
-- TOC entry 11159 (class 0 OID 0)
-- Dependencies: 364
-- Name: volume_iddispovol_seq; Type: SEQUENCE SET; Schema: dvf; Owner: -
--

SELECT pg_catalog.setval('volume_iddispovol_seq', 40354, true);


SET search_path = dvf_annexe, pg_catalog;

--
-- TOC entry 10926 (class 0 OID 147927768)
-- Dependencies: 1246
-- Data for Name: ann_cgi; Type: TABLE DATA; Schema: dvf_annexe; Owner: -
--

COPY ann_cgi (idartcgi, artcgi, libartcgi) FROM stdin;
1	1049*1	CGI 1049 *1 : Acquisition par une société HLM autre qu'un office public
2	1115	CGI 1115 : Exo DE sur achats avec engagement de revente
3	1115*1	CGI 1115*1 : Acquisitions par les marchands de biens
4	1115*2	CGI 1115*2 : Echanges par les marchands de biens
5	1137	CGI 1137 : Acquisitions en vue reboisement
6	1594D*1	CGI 1594 D *1 : MTO Immeuble ou de droits immobiliers 
7	1594D*2	CGI 1594 D * 2 : Vente de terrain à bâtir
8	1594FQA	CGI 1594 FquinquièsA : Ventes par marchands de biens dimmeubles achevés dans les 5 ans 
9	1594FQA*1	CGI 1594 F quinquies A *1 : Vente d'immeuble dans les 5 ans de l'achèvement,TVA perçue en SIE
10	1594FQA*2	CGI 1594 F quinquies A *2 : Vente en état futur d'achèvement d'un immeuble, TVA perçue en SIE
11	1594FQa	CGI 1594Fquinquiesa : Droit de 0,60% sur MTO d'immeuble soumises à TVA déposée sur CA3 
12	1594FQB	CGI 1594 FquinquièsB : Droit de 0,60% sur MTO d'immeuble rénovation urbaine
13	1594FQD	CGI 1594 FquinquièsD : Droit  de 0,60% sur MTO d'immeuble rural
14	1594FQE	CGI 1594 FquinquièsE : Acquisitions jeunes agriculteurs ds territoires ruraux de dvpmt prioritaire 
15	1594FQE I	CGI 1594 FQE I: Acquisitions par jeunes agriculteurs bénéficiaires des aides à l'installation
16	1594FQE II	CGI 1594 FQE II: Acquisitions en vue de donner à bail à de jeunes agriculteurs
17	1594FQF	CGI 1594 FquinquièsF: Droit  de 0,60% sur MTO terres incultes, abandonnées
18	1594FQG	CGI 1594 FquinquièsG : Droit de 0,60% sur ATO immeuble par SAFER et SICA (DOM)
19	1594Fter	CGI 1594Fter : abattement voté conseil général sur MTO immeuble habitation
20	1594H	CGI 1594 H: Acquisitions logements par HLM ou SEM
21	1594Ibis	CGI 1594 I bis : Acquisition dans DOM, d'un immeuble avec engagement de l'affecter à usage d'hôtel
22	1594OGA	CGI 1594OGA : exo enregistrement sur MTO terrains et immeubles soumises à TVA
23	257-7-1*2	CGI 257-7-1 *2 :  Vente en état futur d'achèvement TVA 19,60%, TPF à 0,6% et salaire à 0,1%
24	257-7-1*3	CGI 257-7-1 *3 : Vente de terrain à bâtir soumise à la TVA 19,60 %, DF à 125 EUR et salaire à 0,1%
25	278 sexies I.1	CGI 278 sexies-I.1: Vente aux HLM de terrain à bâtir. TVA à 5,50%, DFà 125 EUR et salaire à 0,05 %
26	278 sexies I.2	CGI 278 sexies-I.2 : Vente aux HLM. TVA au taux  de 5,50 %, DFà 125 EUR et salaire à 0,05 %
27	278 sexies I.3	CGI 278 sexies-I.3: ventes de logements sociaux neufs à usage locatif
28	278bis	CGI 278 bis : TVA au taux réduit
29	278sex-I	CGI 278 sexiès I : TVA au taux réduit sur ATO de TAB et logements sociaux
30	278sexIAM	CGI 278 sexiès IAM : TVA réduite sur ATO de TAB avec TPF à 0,60% en Alsace Moselle
31	296-1-a-*1	CGI 296-1-a *1 : Vente aux HLM immeuble, terrain à bâtir, soumise à TVA ds les DOM (hors Guyane)
32	296-1-a-*2	CGI 296-1-a *2 : VEFA aux HLM d'immeuble, soumise à TVA dans les DOM (hors Guyane)
33	296-1-b-*2	CGI 296-1-b *2 : VEFA d'un immeuble soumise à TVA 8,50% situé dans les DOM (hors Guyane)
34	691bis	CGI 691 bis : Acquisition de TAB soumise à droit fixe de 125 EUR - TVA sur CA3
35	810-IV	CGI 810-IV : Droit fixe exigible sur apports soumis à TVA
\.


--
-- TOC entry 11160 (class 0 OID 0)
-- Dependencies: 1245
-- Name: ann_cgi_idartcgi_seq; Type: SEQUENCE SET; Schema: dvf_annexe; Owner: -
--

SELECT pg_catalog.setval('ann_cgi_idartcgi_seq', 35, true);


--
-- TOC entry 10923 (class 0 OID 147927760)
-- Dependencies: 1243
-- Data for Name: ann_nature_culture; Type: TABLE DATA; Schema: dvf_annexe; Owner: -
--

COPY ann_nature_culture (natcult, libnatcult) FROM stdin;
AB	terrains a bâtir
AG	terrains d'agrément
B	bois
BF	futaies feuillues
BM	futaies mixtes
BO	oseraies
BP	peupleraies
BR	futaies résineuses
BS	taillis sous futaie
BT	taillis simples
CA	carrières
CH	chemin de fer
E	eaux
J	jardins
L	landes
LB	landes boisées
P	prés
PA	pâtures
PC	pacages
PE	prés d'embouche
PH	herbages
PP	prés plantes
S	sols
T	terres
TP	terres plantées
VE	vergers
VI	vignes
\.


--
-- TOC entry 10924 (class 0 OID 147927763)
-- Dependencies: 1244
-- Data for Name: ann_nature_culture_speciale; Type: TABLE DATA; Schema: dvf_annexe; Owner: -
--

COPY ann_nature_culture_speciale (natcultspe, libnatcusp) FROM stdin;
ABREU	Abreuvoirs
ABRIC	Abricotiers
ACACI	Acacias
AEROD	Aérodrome
AIRE	Aire ou airial
ALLEE	Allée (no groupe)
ALLUV	Alluvions
AMAND	Amandiers
ARDOI	Ardoisière
ARGIL	Argilière
ASPER	Aspergerie
AULN	Aulnaie
AVENU	Avenue
BALLA	Ballastière
BAMBO	Bambouseraie
BASS	Bassin
BIEF	Bief
BOUL	Boulaie
BROUS	Broussailles ou buissons
BRUY	Bruyère
BTIGE	Verger exploite en basses tiges
BUIS	Buissière
CAMP	Terrain de camping
CANAL	Canal
CASS	Cassis
CEDRA	Cédratiers
CERCL	Cercliere
CERIS	Cerisaie ou cerisiers
CHASS	Terrain de chasse
CHAT	Châtaigneraie
CHEM	Chemin (non groupe)
CHENE	Chênes
CHLIE	Chênes-lièges
CHTRU	Chênes -truffiers
CHVER	Chênes -verts
CIDRE	Cidre
CITRO	Citronniers
CLAIR	Claires
COING	Cognassiers
COULE	Bois de couleur
CRAY	Crayère
CRESS	Cressonnière
CRYPT	Cryptomeria
DIGUE	Digues
DUNE	Dunes
EAU	Pièce d'eau
ECOLE	Ecole
EPICE	Epicéas
ESPAL	Verger exploite en espaliers
ETANG	Etangs
EUCAL	Eucalyptus
FALAI	Falaise
FAMIL	Familial (jardin)
FER	Chemin de fer
FILAO	Filao
FLOR	Jardin floral
FONT	Fontaine
FOSSE	Fosse
FOUG	Fougeraie
FRAMB	Framboisiers
FRICH	Friche
GAREN	Garenne
GENET	Genets
GLAIS	Glaisière
GRAVE	Gravière
HAIES	Haies fruitières
HERB	Herbage
HETRE	Hêtres
HIST	Dépendances de monument historique
HORT	Jardin horticole
HOUBL	Houblon
HTIGE	Verger exploite en hautes tiges
HUITR	Parc à huîtres
IMM	Dépendances d'ensemble immobilier
IMPRO	Lande improductive
INTEN	Verger industriel
JARD	Jardin d'agrément
JETT	Jettins
JOUAL	Joualle
KIWIS	Kiwis
LAC	Lac
LAGUN	Lagune
LAVOI	Lavoir
LEGUM	Légumière de plein champ
MAQUI	Maquis
MARAI	Pré marais
MARAM	Jardin maraîcher aménagé
MARE	Mare
MAREC	Marécage
MARN	Marnière
MARNA	Jardin maraîcher non aménagé
MELEZ	Mélèzes
MOTTE	Mottes
MUR	Muraies ou muriers (vergers)
NATUR	Bois naturel
NOISE	Noiseraie ou noisetiers
NOYER	Noyeraie ou noyers
NPECH	Etang non pêchable
OLIVE	Oliveraie ou oliviers
ORANG	Orangers (verger)
ORME	Ormaie ou ormes
PACAG	Pacage
PAFEU	Pare -feux
PALMI	Bois palmiste
PARC	Parc
PASS	Passage (no groupe)
PATIS	Patis
PATUR	Pâture plantée
PECH	Etangs pêchables
PECHE	Pêchers
PEPIN	Pépinières
PIEDS	Pieds -mères (vignes)
PIERR	Pierraille. pierrier
PIN	Pins
PLAGE	Plage
PLATR	Plâtrière
PLVEN	Vergers de plein vent
POIRE	Poiriers
POMME	Pommiers
POTAG	Jardin potager
PROTE	Bois de protection
PRUNE	Pruniers
RAIS	Raisin de table
RESER	Réservoir
RESIN	Résineux
RIVAG	Rivage (bois de)
RIZ	Rizière
ROC	Rocs ou rochers
ROUI	Routoir ou ruissoir
RUE	Rue
RUINE	Ruines
SABLE	Sablière
SALIN	Marais salant
SAPIN	Sapins ou sapinière
SART	Sartières
SAULE	Saulaie ou saussaie
SERRE	Serre
SOL	Sol
SOURC	Source
SPORT	Terrain de sport
TAMAR	Tamarin
TAUZ	Taillis tauzin
TERRI	Terrils
TOURB	Tourbière
TOUYA	Touyas
VADC	Vins d'appellation d'origine contrôlée
VAGUE	Terrain vague
VANIL	Vanille
VAOC	Vins d'appellation d'origine contrôlée
VCHAS	Chasselat
VDQS	Vins délimités de qualité supérieure
VIGNE	Vigne
VIVIE	Vivier
\.


--
-- TOC entry 10928 (class 0 OID 147927774)
-- Dependencies: 1248
-- Data for Name: ann_nature_mutation; Type: TABLE DATA; Schema: dvf_annexe; Owner: -
--

COPY ann_nature_mutation (idnatmut, libnatmut) FROM stdin;
1	Vente
2	Vente en l'état futur d'achèvement
3	Expropriation
4	Vente terrain à bâtir
5	Adjudication
6	Echange
\.


--
-- TOC entry 11161 (class 0 OID 0)
-- Dependencies: 1247
-- Name: ann_nature_mutation_idnatmut_seq; Type: SEQUENCE SET; Schema: dvf_annexe; Owner: -
--

SELECT pg_catalog.setval('ann_nature_mutation_idnatmut_seq', 6, true);


--
-- TOC entry 10929 (class 0 OID 147927778)
-- Dependencies: 1249
-- Data for Name: ann_type_local; Type: TABLE DATA; Schema: dvf_annexe; Owner: -
--

COPY ann_type_local (codtyploc, libtyploc) FROM stdin;
1	Maison
2	Appartement
3	Dépendance
4	Local industriel, commercial ou assimilé
\.


--
-- TOC entry 10936 (class 0 OID 150797923)
-- Dependencies: 2038
-- Data for Name: ann_typologie; Type: TABLE DATA; Schema: dvf_annexe; Owner: -
--

COPY ann_typologie (codtypbien, libtypbien, niv1, libniv1, niv2, libniv2, niv3, libniv3, niv4, libniv4, niv5, libniv5) FROM stdin;
101	BATI - INDETERMINE : Vefa sans descriptif	1	BATI	10	BATI - INDETERMINE	101	BATI - INDETERMINE : Vefa sans descriptif	101	BATI - INDETERMINE : Vefa sans descriptif	101	BATI - INDETERMINE : Vefa sans descriptif
102	BATI - INDETERMINE : Vente avec volume(s)	1	BATI	10	BATI - INDETERMINE	102	BATI - INDETERMINE : Vente avec volume(s)	102	BATI - INDETERMINE : Vente avec volume(s)	102	BATI - INDETERMINE : Vente avec volume(s)
110	MAISON - INDETERMINEE	1	BATI	11	MAISON	110	MAISON - INDETERMINEE	110	MAISON - INDETERMINEE	110	MAISON - INDETERMINEE
111	UNE MAISON	1	BATI	11	MAISON	111	UNE MAISON	111	UNE MAISON	111	UNE MAISON
112	DES MAISONS	1	BATI	11	MAISON	112	DES MAISONS	112	DES MAISONS	112	DES MAISONS
120	APPARTEMENT INDETERMINE	1	BATI	12	APPARTEMENT	120	APPARTEMENT INDETERMINE	120	APPARTEMENT INDETERMINE	120	APPARTEMENT INDETERMINE
121	UN APPARTEMENT	1	BATI	12	APPARTEMENT	121	UN APPARTEMENT	121	UN APPARTEMENT	121	UN APPARTEMENT
122	DEUX APPARTEMENTS	1	BATI	12	APPARTEMENT	122	DEUX APPARTEMENTS	122	DEUX APPARTEMENTS	122	DEUX APPARTEMENTS
131	UNE DEPENDANCE	1	BATI	13	DEPENDANCE	131	UNE DEPENDANCE	131	UNE DEPENDANCE	131	UNE DEPENDANCE
132	DES DEPENDANCES	1	BATI	13	DEPENDANCE	132	DES DEPENDANCES	132	DES DEPENDANCES	132	DES DEPENDANCES
14	ACTIVITE	1	BATI	14	ACTIVITE	14	ACTIVITE	14	ACTIVITE	14	ACTIVITE
151	BATI MIXTE - LOGEMENTS	1	BATI	15	BATI MIXTE	151	BATI MIXTE - LOGEMENTS	151	BATI MIXTE - LOGEMENTS	151	BATI MIXTE - LOGEMENTS
152	BATI MIXTE - LOGEMENT/ACTIVITE	1	BATI	15	BATI MIXTE	152	BATI MIXTE - LOGEMENT/ACTIVITE	152	BATI MIXTE - LOGEMENT/ACTIVITE	152	BATI MIXTE - LOGEMENT/ACTIVITE
20	TERRAIN NON BATIS INDETERMINE	2	NON BATI	20	TERRAIN NON BATIS INDETERMINE	20	TERRAIN NON BATIS INDETERMINE	20	TERRAIN NON BATIS INDETERMINE	20	TERRAIN NON BATIS INDETERMINE
21	TERRAIN DE TYPE TAB	2	NON BATI	21	TERRAIN DE TYPE TAB	21	TERRAIN DE TYPE TAB	21	TERRAIN DE TYPE TAB	21	TERRAIN DE TYPE TAB
221	TERRAIN D'AGREMENT	2	NON BATI	22	TERRAIN ARTIFICIALISE	221	TERRAIN D'AGREMENT	221	TERRAIN D'AGREMENT	221	TERRAIN D'AGREMENT
222	TERRAIN D'EXTRACTION	2	NON BATI	22	TERRAIN ARTIFICIALISE	222	TERRAIN D'EXTRACTION	222	TERRAIN D'EXTRACTION	222	TERRAIN D'EXTRACTION
223	TERRAIN DE TYPE RESEAU	2	NON BATI	22	TERRAIN ARTIFICIALISE	223	TERRAIN DE TYPE RESEAU	223	TERRAIN DE TYPE RESEAU	223	TERRAIN DE TYPE RESEAU
229	TERRAIN ARTIFICIALISE MIXTE	2	NON BATI	22	TERRAIN ARTIFICIALISE	229	TERRAIN ARTIFICIALISE MIXTE	229	TERRAIN ARTIFICIALISE MIXTE	229	TERRAIN ARTIFICIALISE MIXTE
2311	TERRAIN VITICOLE	2	NON BATI	23	TERRAIN NATUREL	231	TERRAIN AGRICOLE	2311	TERRAIN VITICOLE	2311	TERRAIN VITICOLE
2312	TERRAIN VERGER	2	NON BATI	23	TERRAIN NATUREL	231	TERRAIN AGRICOLE	2312	TERRAIN VERGER	2312	TERRAIN VERGER
2313	TERRAIN DE TYPE TERRE ET PRE	2	NON BATI	23	TERRAIN NATUREL	231	TERRAIN AGRICOLE	2313	TERRAIN DE TYPE TERRE ET PRE	2313	TERRAIN DE TYPE TERRE ET PRE
2319	TERRAIN AGRICOLE MIXTE	2	NON BATI	23	TERRAIN NATUREL	231	TERRAIN AGRICOLE	2319	TERRAIN AGRICOLE MIXTE	2319	TERRAIN AGRICOLE MIXTE
232	TERRAIN FORESTIER	2	NON BATI	23	TERRAIN NATUREL	232	TERRAIN FORESTIER	232	TERRAIN FORESTIER	232	TERRAIN FORESTIER
233	TERRAIN LANDES ET EAUX	2	NON BATI	23	TERRAIN NATUREL	233	TERRAIN LANDES ET EAUX	233	TERRAIN LANDES ET EAUX	233	TERRAIN LANDES ET EAUX
239	TERRAIN NATUREL MIXTE	2	NON BATI	23	TERRAIN NATUREL	239	TERRAIN NATUREL MIXTE	239	TERRAIN NATUREL MIXTE	239	TERRAIN NATUREL MIXTE
\.


SET search_path = dvf, pg_catalog;

--
-- TOC entry 10573 (class 1259 OID 151713408)
-- Name: l_codinsee_idx_gin_dvf; Type: INDEX; Schema: dvf; Owner: -
--

CREATE INDEX l_codinsee_idx_gin_dvf ON dvf.mutation USING gin (l_codinsee);


--
-- TOC entry 10581 (class 2620 OID 147927757)
-- Name: insert_adresse_dispoparc_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_adresse_dispoparc_trigger BEFORE INSERT ON dvf.adresse_dispoparc FOR EACH ROW EXECUTE PROCEDURE adresse_dispoparc_insert_trigger();


--
-- TOC entry 10582 (class 2620 OID 147927759)
-- Name: insert_adresse_local_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_adresse_local_trigger BEFORE INSERT ON dvf.adresse_local FOR EACH ROW EXECUTE PROCEDURE adresse_local_insert_trigger();


--
-- TOC entry 10577 (class 2620 OID 147927749)
-- Name: insert_adresse_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_adresse_trigger BEFORE INSERT ON dvf.adresse FOR EACH ROW EXECUTE PROCEDURE adresse_insert_trigger();


--
-- TOC entry 10575 (class 2620 OID 147927741)
-- Name: insert_disposition_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_disposition_trigger BEFORE INSERT ON dvf.disposition FOR EACH ROW EXECUTE PROCEDURE disposition_insert_trigger();


--
-- TOC entry 10580 (class 2620 OID 147927755)
-- Name: insert_lot_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_lot_trigger BEFORE INSERT ON dvf.lot FOR EACH ROW EXECUTE PROCEDURE lot_insert_trigger();


--
-- TOC entry 10574 (class 2620 OID 147927739)
-- Name: insert_mutation_article_cgi_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_mutation_article_cgi_trigger BEFORE INSERT ON dvf.mutation_article_cgi FOR EACH ROW EXECUTE PROCEDURE mutation_article_cgi_insert_trigger();


--
-- TOC entry 10576 (class 2620 OID 147927745)
-- Name: insert_parcelle_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_parcelle_trigger BEFORE INSERT ON dvf.parcelle FOR EACH ROW EXECUTE PROCEDURE parcelle_insert_trigger();


--
-- TOC entry 10578 (class 2620 OID 147927751)
-- Name: insert_suf_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_suf_trigger BEFORE INSERT ON dvf.suf FOR EACH ROW EXECUTE PROCEDURE suf_insert_trigger();


--
-- TOC entry 10579 (class 2620 OID 147927753)
-- Name: insert_volume_trigger; Type: TRIGGER; Schema: dvf; Owner: -
--

CREATE TRIGGER insert_volume_trigger BEFORE INSERT ON dvf.volume FOR EACH ROW EXECUTE PROCEDURE volume_insert_trigger();


-- Completed on 2019-05-20 13:09:10

--
-- PostgreSQL database dump complete
--

